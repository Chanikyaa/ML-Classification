# Security, privacy, and limitations

- This is a local educational demo, not a hardened public inference service.
- The API accepts only the exact named features and rejects unknown fields; no arbitrary code or file upload is exposed.
- Do not expose the API to the public internet without authentication, request limits, monitoring, and deployment-specific hardening.
- `joblib` artifacts must be treated as trusted executable Python serialization. Never load an artifact from an untrusted source.
- No user data is persisted by the API.
- The model is trained on a small public educational dataset. Dataset bias, distribution shift, and model misuse are not addressed.
- Prediction probabilities are model scores and should not be assumed calibrated.
