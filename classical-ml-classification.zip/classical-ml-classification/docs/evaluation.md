# Evaluation protocol

## Metrics

- **Accuracy:** fraction of correct predictions; easy to interpret but can obscure class-level errors.
- **Macro F1:** computes F1 per class and averages equally, so each class matters regardless of frequency.
- **Confusion matrix / per-class report:** makes class-specific mistakes visible.
- **Cross-validation macro F1:** compares candidate model configurations using only training data.
- **Permutation importance:** estimates the score drop after shuffling one feature; correlated features can make this unstable.

## Baseline and model comparison

The majority-class `DummyClassifier` is the baseline. Logistic regression with standardization and a random forest are compared using five-fold stratified CV and small grids. The best CV model is evaluated once on the held-out test split. Run `python -m classical_ml.train` to generate `reports/evaluation.json` and `reports/permutation_importance.csv`; those reports are the measured results for the current installed versions and seed.

## Reproducibility and limits

The dataset and split are deterministic, but exact scores may vary across scikit-learn versions and platforms. The small, classic dataset is not representative of real-world production distribution shift. The configured 0.80 macro-F1 CI gate is an educational smoke gate, not a universal acceptance threshold. Do not claim clinical, commercial, or generalization validity from this demo.
