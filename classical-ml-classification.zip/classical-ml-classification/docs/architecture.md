# Architecture and data flow

```mermaid
flowchart TD
    A[scikit-learn Wine dataset] --> B[Stratified train/test split]
    B --> C[Training split only]
    C --> D[5-fold CV and hyperparameter search]
    D --> E[Selected model]
    B --> F[Held-out test split]
    E --> G[Final evaluation]
    F --> G
    G --> H[JSON report and permutation importance]
    E --> I[Versioned joblib artifact]
    I --> J[FastAPI validation]
    J --> K[Prediction and probabilities]
```

## Boundaries

- Dataset loading and splitting live in `data.py`.
- Model candidates, cross-validation, and metrics live in `modeling.py`.
- The CLI writes the artifact and reports.
- The API loads a trained artifact and validates exact feature names before inference.
- The CI gate checks a minimum macro-F1 score on the fixed educational test split.

## Leakage controls

- The split is stratified and uses a fixed random seed.
- Hyperparameter selection uses only the training split and 5-fold cross-validation.
- The held-out test set is used for final reporting, not model selection.
- Permutation importance is a post-hoc explanation on the held-out set; it is not used to tune the model. For formal model selection, use a separate validation split or nested CV.
