# Career readiness guide

## Target roles and skills

Relevant roles: Machine Learning Engineer, Data Scientist, Applied AI Engineer, and ML Platform Engineer. Demonstrated skills: leakage-aware splitting, pipelines, cross-validation, hyperparameter search, baseline comparisons, macro-F1, confusion matrices, permutation importance, model serialization, FastAPI, testing, Docker, and CI.

## Requirement-to-feature mapping

- Data validation and reproducibility → `data.py`, fixed seed, stratified split.
- Baseline and feature engineering → majority-class baseline, standardized logistic-regression pipeline.
- Model selection → 5-fold CV and grid search on training data.
- Error analysis → per-class report and confusion matrix.
- Model interpretation → permutation importance report.
- Deployable inference → FastAPI `/predict`, `/model`, `/health`.
- MLOps foundations → artifact metadata, CI training/evaluation gate, Docker configuration.

## Resume bullet templates

1. Built a reproducible classification pipeline using **[model]** and stratified 5-fold CV, achieving **[verified held-out macro-F1]** versus **[baseline macro-F1]** on the Wine Recognition dataset.
2. Deployed a typed FastAPI prediction endpoint with exact feature validation and versioned model metadata, verified by **[number]** automated tests.
3. Added automated evaluation reports and a CI quality gate that checks **[metric and threshold]**, reducing manual regression checks by **[measured amount]**.

Fill bracketed values only from your own runs. Do not present this educational dataset as business impact.

## Results to collect

- Exact package versions and model version.
- CV scores and held-out accuracy/macro-F1.
- Baseline versus selected-model scores.
- Per-class precision/recall/F1 and confusion matrix.
- Prediction latency under a defined workload.
- Test count and CI run URL after a real GitHub run.

## Five-minute demo script

1. (0:00–0:45) Explain the multiclass prediction task and the small public dataset.
2. (0:45–1:30) Show deterministic stratified splitting and why the test split is held out.
3. (1:30–2:30) Run training; explain the dummy baseline, logistic regression pipeline, random forest, and CV search.
4. (2:30–3:20) Inspect evaluation JSON, macro-F1, confusion matrix, and feature importance.
5. (3:20–4:20) Start the API and call `/model` and `/predict`.
6. (4:20–5:00) Explain limitations, artifact trust, and next steps for monitoring/drift.

## Two-minute architecture explanation

The dataset module loads the packaged Wine dataset and makes a reproducible stratified split. Model training evaluates a majority-class baseline and tunes two models using cross-validation restricted to training data. The chosen estimator is then measured on the held-out test split. The CLI saves a model artifact with feature names, class names, version metadata, and metrics, alongside machine-readable evaluation reports. FastAPI loads the artifact, rejects missing or extra feature names, and returns a class prediction and probabilities. CI runs tests, retrains, and checks a documented macro-F1 threshold. The result is a reproducible educational pipeline, not a production-grade or domain-validated model.

## Interview questions and answers

1. **Why stratify the split?** It preserves approximate class proportions in train and test, which matters with relatively few rows per class.
2. **Why have a baseline?** A complex model should be compared with a simple reference; otherwise the score has little context.
3. **Why macro-F1?** Each class contributes equally, unlike weighted F1 or accuracy, so weak minority-class performance is more visible.
4. **What is leakage?** Information from evaluation data or future outcomes influencing training or model selection. It makes metrics overly optimistic.
5. **Why use a pipeline?** Scaling is fit within each CV fold rather than globally, preventing fold-validation statistics from leaking into training.
6. **Why is scaling needed for logistic regression?** Features on different scales can affect optimization and regularization.
7. **Why include a random forest?** It models nonlinear relationships and interactions without requiring feature scaling.
8. **What does cross-validation estimate?** Performance variability across folds of the training set under the chosen split strategy; it is not a guarantee of production performance.
9. **Why keep a held-out test set?** To estimate final generalization after model and hyperparameter selection are complete.
10. **What is the confusion matrix for?** It shows which true classes are mistaken for which predicted classes.
11. **How does permutation importance work?** It shuffles one feature and measures the drop in a chosen score; correlated features can dilute or distort importance.
12. **Are probabilities calibrated?** Not necessarily. Calibration must be measured and may require calibration methods on validation data.
13. **Why serialize metadata with the model?** The API needs feature ordering, class names, and version context to interpret predictions consistently.
14. **Why reject extra API fields?** It catches client/schema mismatch rather than silently ignoring unexpected input.
15. **Why not trust joblib files from strangers?** Deserialization can execute code; only load trusted artifacts.
16. **What is concept drift?** The relationship between features and targets changes over time; a static benchmark cannot detect it by itself.
17. **How would you monitor production?** Track input schema/ranges, prediction distributions, latency/errors, and—when labels arrive—quality metrics and drift.
18. **Why not optimize against the test set repeatedly?** Repeated decisions based on test scores overfit the evaluation process itself.
19. **What does the CI threshold mean?** It is a project-specific regression guard, not proof of universal model quality.
20. **How would you scale this?** Add artifact registry, explicit model promotion, request authentication/rate limits, observability, and controlled monitoring only when requirements justify them.

## Debugging and system-design scenarios

1. **CV score high, test score low:** check leakage, split representativeness, variance, and tune only with training/validation data.
2. **API says features are missing:** compare the request keys with `/model`'s exact feature list and check spelling/types.
3. **Scores differ between machines:** compare dependency versions, seeds, preprocessing, and artifact versions.
4. **A feature ranks highly but is correlated with another:** inspect feature correlation and stability across folds; avoid causal interpretations.
5. **Production distribution shifts:** alert on feature/prediction drift, validate incoming data, collect delayed labels, and retrain only after offline evaluation and approval.

## Likely interviewer objections

- **“The dataset is tiny and old.”** Agree. It demonstrates workflow mechanics, not production performance; a later version should use a larger task-relevant licensed dataset.
- **“You chose the threshold yourself.”** Explain that it is an illustrative CI guard and must be set from business/error costs for a real use case.
- **“Did you deploy it publicly?”** Only claim deployment if you actually do so and can show the URL and operational evidence.
- **“Does feature importance explain causality?”** No. It describes model reliance under a chosen scoring procedure, not causal effects.
