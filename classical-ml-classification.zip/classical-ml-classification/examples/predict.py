"""Print a sample prediction after training."""
import joblib
import pandas as pd
from sklearn.datasets import load_wine

artifact = joblib.load("artifacts/wine_classifier.joblib")
sample = load_wine(as_frame=True).data.iloc[[0]][artifact["feature_names"]]
prediction = int(artifact["model"].predict(sample)[0])
print({"predicted_class": artifact["target_names"][prediction], "model_version": artifact["model_version"]})
