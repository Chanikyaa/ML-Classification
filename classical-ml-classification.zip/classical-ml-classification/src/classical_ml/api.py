"""FastAPI prediction endpoint for a locally trained artifact."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, ConfigDict, Field

DEFAULT_ARTIFACT = Path(os.getenv("MODEL_ARTIFACT", Path(__file__).resolve().parents[2] / "artifacts" / "wine_classifier.joblib"))
app = FastAPI(title="Classical ML Wine Classifier", version="0.1.0",
              description="Educational API for the scikit-learn Wine Recognition dataset.")


class PredictionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    features: dict[str, float] = Field(..., description="All 13 model features, by exact feature name")


class PredictionResponse(BaseModel):
    predicted_class_id: int
    predicted_class: str
    probabilities: dict[str, float] | None
    model_version: str


@lru_cache(maxsize=2)
def load_artifact(path: str) -> dict[str, Any]:
    artifact = Path(path)
    if not artifact.is_file():
        raise FileNotFoundError(f"Model artifact not found at {artifact}. Run python -m classical_ml.train first.")
    return joblib.load(artifact)



@app.get("/", response_class=HTMLResponse)
def home() -> str:
    """Minimal demo page; shows the API contract and links to interactive docs."""
    return """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Classical ML Demo</title>
<style>body{font:16px system-ui;max-width:760px;margin:3rem auto;padding:0 1rem;line-height:1.5}code,pre{background:#f3f4f6;padding:.2rem .4rem;border-radius:5px}a{color:#2457a7}</style></head><body>
<h1>Classical ML Classifier</h1><p>This demo serves the Wine Recognition educational classifier. Train the model before using prediction endpoints.</p>
<p><a href="/docs">Open interactive API docs</a> · <a href="/health">Health check</a> · <a href="/model">Model metadata</a></p>
<h2>Try a prediction</h2><p>Submit all 13 named features through <code>POST /predict</code>. The endpoint rejects missing or unexpected fields.</p>
<pre>{"features":{"alcohol":14.23,"malic_acid":1.71,"ash":2.43,"alcalinity_of_ash":15.6,"magnesium":127,"total_phenols":2.8,"flavanoids":3.06,"nonflavanoid_phenols":0.28,"proanthocyanins":2.29,"color_intensity":5.64,"hue":1.04,"od280/od315_of_diluted_wines":3.92,"proline":1065}}</pre>
<p>Use the Swagger UI at <a href="/docs">/docs</a> to execute this request. This application is educational and has no authentication.</p></body></html>"""

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/model")
def model_info() -> dict[str, Any]:
    try:
        artifact = load_artifact(str(DEFAULT_ARTIFACT))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"model_version": artifact["model_version"], "dataset": artifact["dataset"],
            "feature_names": artifact["feature_names"], "class_names": artifact["target_names"]}


@app.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest) -> PredictionResponse:
    try:
        artifact = load_artifact(str(DEFAULT_ARTIFACT))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    expected = artifact["feature_names"]
    supplied = set(request.features)
    missing, extra = sorted(set(expected) - supplied), sorted(supplied - set(expected))
    if missing or extra:
        raise HTTPException(status_code=422, detail={"missing_features": missing, "unexpected_features": extra})
    values = [request.features[name] for name in expected]
    if any(not pd.notna(value) or abs(value) == float("inf") for value in values):
        raise HTTPException(status_code=422, detail="Feature values must be finite numbers")
    frame = pd.DataFrame([request.features], columns=expected)
    model = artifact["model"]
    predicted = int(model.predict(frame)[0])
    probabilities = None
    if hasattr(model, "predict_proba"):
        raw = model.predict_proba(frame)[0]
        probabilities = {artifact["target_names"][int(label)]: float(prob) for label, prob in zip(model.classes_, raw)}
    return PredictionResponse(predicted_class_id=predicted, predicted_class=artifact["target_names"][predicted],
                              probabilities=probabilities, model_version=artifact["model_version"])
