"""End-to-end classical machine learning classification example."""
__version__ = "0.1.0"
