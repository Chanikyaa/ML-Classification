"""Deterministic dataset loading and leakage-safe splitting."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split

RANDOM_STATE = 42
TARGET_NAME = "target"


@dataclass(frozen=True)
class DatasetBundle:
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series
    feature_names: list[str]
    target_names: list[str]
    dataset_description: str


def load_dataset() -> tuple[pd.DataFrame, pd.Series, list[str], list[str], str]:
    """Load sklearn's Wine Recognition dataset without a network download."""
    dataset = load_wine(as_frame=True)
    X = dataset.data.copy()
    y = dataset.target.copy().rename(TARGET_NAME)
    return X, y, list(dataset.feature_names), list(dataset.target_names), str(dataset.DESCR).split("\n\n")[:2].__str__()


def make_split(test_size: float = 0.2, random_state: int = RANDOM_STATE) -> DatasetBundle:
    if not 0 < test_size < 1:
        raise ValueError("test_size must be between 0 and 1")
    X, y, features, classes, description = load_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return DatasetBundle(X_train, X_test, y_train, y_test, features, classes, description)
