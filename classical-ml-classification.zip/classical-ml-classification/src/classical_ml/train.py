"""Training CLI: python -m classical_ml.train"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
import sklearn
import os

from classical_ml.data import make_split
from classical_ml.modeling import train_and_evaluate

ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    parser = argparse.ArgumentParser(description="Train, evaluate, and save a classical ML classifier")
    parser.add_argument("--artifacts-dir", default=str(ROOT / "artifacts"))
    parser.add_argument("--reports-dir", default=str(ROOT / "reports"))
    args = parser.parse_args()
    artifacts_dir, reports_dir = Path(args.artifacts_dir), Path(args.reports_dir)
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    bundle = make_split()
    result = train_and_evaluate(bundle)
    version = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    artifact_path = artifacts_dir / "wine_classifier.joblib"
    joblib.dump({
        "model": result.model,
        "feature_names": bundle.feature_names,
        "target_names": bundle.target_names,
        "model_version": version,
        "dataset": "scikit-learn Wine Recognition dataset",
        "sklearn_version": sklearn.__version__,
        "metrics": result.metrics,
    }, artifact_path)
    report = {
        "model_version": version,
        "dataset": "scikit-learn Wine Recognition dataset",
        "sklearn_version": sklearn.__version__,
        "train_samples": int(len(bundle.y_train)),
        "test_samples": int(len(bundle.y_test)),
        "cv_summary": result.cv_summary,
        "metrics": result.metrics,
        "permutation_importance": result.feature_importance,
        "artifact_path": str(artifact_path),
        "evaluation_notes": "Test split is held out from hyperparameter selection. Metrics are local experimental results, not production guarantees.",
    }
    (reports_dir / "evaluation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    # Optional experiment tracking: install with `pip install -e ".[tracking]"` and set ENABLE_MLFLOW=1.
    if os.getenv("ENABLE_MLFLOW", "0").lower() in {"1", "true", "yes"}:
        try:
            import mlflow
            mlflow.set_experiment(os.getenv("MLFLOW_EXPERIMENT_NAME", "classical-ml-classification"))
            with mlflow.start_run(run_name=version):
                mlflow.log_params({"selected_model": result.metrics["selected_model"],
                                   "random_state": 42, "cv_folds": 5,
                                   **{f"best_{k}": str(v) for k, v in result.metrics["best_parameters"].items()}})
                mlflow.log_metrics({"test_accuracy": result.metrics["test_accuracy"],
                                    "test_f1_macro": result.metrics["test_f1_macro"],
                                    "baseline_test_accuracy": result.metrics["baseline_test_accuracy"],
                                    "baseline_test_f1_macro": result.metrics["baseline_test_f1_macro"]})
                mlflow.log_artifact(str(reports_dir / "evaluation.json"))
                mlflow.log_artifact(str(artifact_path))
        except ImportError as exc:
            raise RuntimeError("ENABLE_MLFLOW=1 requires the optional dependency: pip install -e '.[tracking]'") from exc
    pd.DataFrame(result.feature_importance).to_csv(reports_dir / "permutation_importance.csv", index=False)
    print(json.dumps({"artifact": str(artifact_path), "report": str(reports_dir / "evaluation.json"),
                      "selected_model": result.metrics["selected_model"],
                      "test_accuracy": result.metrics["test_accuracy"],
                      "test_f1_macro": result.metrics["test_f1_macro"]}, indent=2))


if __name__ == "__main__":
    main()
