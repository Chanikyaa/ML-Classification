"""Model training and metrics. Test data is only used for final evaluation."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from classical_ml.data import DatasetBundle, RANDOM_STATE


@dataclass
class TrainingResult:
    model: Any
    baseline: Any
    metrics: dict[str, Any]
    cv_summary: dict[str, float]
    feature_importance: list[dict[str, Any]]


def build_candidates() -> dict[str, Any]:
    return {
        "logistic_regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=3000, random_state=RANDOM_STATE)),
        ]),
        "random_forest": RandomForestClassifier(random_state=RANDOM_STATE, class_weight="balanced"),
    }


def train_and_evaluate(bundle: DatasetBundle) -> TrainingResult:
    """Tune on training data with CV, then evaluate the selected model once on test data."""
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    candidates = build_candidates()
    grids = {
        "logistic_regression": {"model__C": [0.1, 1.0, 10.0]},
        "random_forest": {"n_estimators": [100, 200], "max_depth": [None, 5, 10]},
    }
    searches = []
    cv_summary: dict[str, float] = {}
    for name, estimator in candidates.items():
        search = GridSearchCV(estimator, grids[name], scoring="f1_macro", cv=cv, n_jobs=1, refit=True)
        search.fit(bundle.X_train, bundle.y_train)
        searches.append((name, search))
        cv_summary[f"{name}_best_cv_f1_macro"] = float(search.best_score_)
    best_name, best_search = max(searches, key=lambda pair: pair[1].best_score_)
    model = best_search.best_estimator_

    baseline = DummyClassifier(strategy="most_frequent")
    baseline.fit(bundle.X_train, bundle.y_train)
    pred = model.predict(bundle.X_test)
    baseline_pred = baseline.predict(bundle.X_test)
    labels = list(range(len(bundle.target_names)))
    metrics: dict[str, Any] = {
        "selected_model": best_name,
        "best_parameters": best_search.best_params_,
        "test_accuracy": float(accuracy_score(bundle.y_test, pred)),
        "test_f1_macro": float(f1_score(bundle.y_test, pred, average="macro")),
        "baseline_test_accuracy": float(accuracy_score(bundle.y_test, baseline_pred)),
        "baseline_test_f1_macro": float(f1_score(bundle.y_test, baseline_pred, average="macro")),
        "classification_report": classification_report(
            bundle.y_test, pred, labels=labels, target_names=bundle.target_names, output_dict=True, zero_division=0
        ),
        "confusion_matrix": confusion_matrix(bundle.y_test, pred, labels=labels).tolist(),
        "class_names": bundle.target_names,
        "test_samples": int(len(bundle.y_test)),
        "random_state": RANDOM_STATE,
    }
    # Permutation importance is measured only on the held-out test set for model interpretation;
    # it must not be used to select features or tune the model.
    from sklearn.inspection import permutation_importance
    importance = permutation_importance(model, bundle.X_test, bundle.y_test, scoring="f1_macro", n_repeats=10,
                                        random_state=RANDOM_STATE, n_jobs=1)
    feature_importance = sorted([
        {"feature": name, "importance_mean": float(mean), "importance_std": float(std)}
        for name, mean, std in zip(bundle.feature_names, importance.importances_mean, importance.importances_std)
    ], key=lambda item: item["importance_mean"], reverse=True)
    return TrainingResult(model, baseline, metrics, cv_summary, feature_importance)
