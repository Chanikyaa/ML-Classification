# End-to-End Classical ML Classification

A reproducible, tested classification workflow that compares a simple baseline with tuned classical models, reports held-out performance, explains feature importance, and serves predictions through FastAPI.

## Problem and intended users

This repository demonstrates the end-to-end mechanics of a supervised multiclass classification project for ML engineering interviews. It uses the small public Wine Recognition dataset bundled with scikit-learn. It is an educational example, not a production decision system.

## Features

- Deterministic dataset loading without network access.
- Stratified train/test split and explicit leakage prevention.
- Majority-class baseline, standardized logistic regression, and random forest.
- Five-fold stratified CV and grid search on training data only.
- Accuracy, macro-F1, confusion matrix, per-class report, and permutation importance.
- Versioned joblib model artifact and JSON/CSV evaluation reports.
- FastAPI prediction endpoint with strict feature validation.
- Reproducible EDA profile, optional MLflow experiment tracking, tests, Dockerfile, Compose, and GitHub Actions CI.

## Architecture

```mermaid
flowchart LR
  A[Packaged Wine dataset] --> B[Stratified split]
  B --> C[CV and tuning on train]
  C --> D[Selected model]
  D --> E[Held-out test evaluation]
  D --> F[Versioned artifact]
  F --> G[FastAPI validation and prediction]
  E --> H[JSON metrics and feature importance]
```

See [architecture](docs/architecture.md), [evaluation](docs/evaluation.md), and [security notes](docs/security.md).

## Prerequisites and setup

Python 3.10+ is recommended. Dataset loading is local; no paid API or external dataset download is needed.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
```

Windows PowerShell activation: `.venv\\Scripts\\Activate.ps1`.

## Train and evaluate

```bash
pytest -q
python scripts/eda.py
python -m classical_ml.train
python scripts/check_regression.py
python examples/predict.py
```

The training command writes `artifacts/wine_classifier.joblib`, `reports/evaluation.json`, and `reports/permutation_importance.csv`. The downloadable ZIP includes a sample locally trained artifact and evaluation report so the API can be tried immediately; generated artifacts remain ignored by Git and should be regenerated using the commands above when changing code or dependencies.

## Optional MLflow experiment tracking

Install `python -m pip install -e ".[tracking]"`, then set `ENABLE_MLFLOW=1` before training. The CLI logs model selection parameters, held-out metrics, and report/artifact files to the configured MLflow tracking URI (local MLflow default unless configured otherwise). MLflow is optional so the core project runs without it. This integration is implemented but was not exercised in this environment.

## Run the API

```bash
uvicorn classical_ml.api:app --reload
```

Open `http://127.0.0.1:8000/` for the demo page or `http://127.0.0.1:8000/docs`. Endpoints: `GET /health`, `GET /model`, `POST /predict`. Train once before calling `/model` or `/predict`.

Example request body (all 13 exact feature names are required):

```json
{
  "features": {
    "alcohol": 14.23,
    "malic_acid": 1.71,
    "ash": 2.43,
    "alcalinity_of_ash": 15.6,
    "magnesium": 127,
    "total_phenols": 2.8,
    "flavanoids": 3.06,
    "nonflavanoid_phenols": 0.28,
    "proanthocyanins": 2.29,
    "color_intensity": 5.64,
    "hue": 1.04,
    "od280/od315_of_diluted_wines": 3.92,
    "proline": 1065
  }
}
```

Actual predictions and scores depend on the trained artifact and package versions. Use `/model` to inspect feature names.

## Docker

```bash
docker compose up --build
```

The image trains a model during build and starts the API. This is a convenient demonstration, not a recommended large-scale model delivery pattern.

## Evaluation and measured results

Run `python -m classical_ml.train` to generate the actual metrics for your environment. The script compares a majority-class baseline against tuned models and reports held-out accuracy, macro-F1, per-class scores, confusion matrix, CV scores, and permutation importance. No score is hard-coded into this README. The CI gate is set to macro-F1 >= 0.80 for this fixed educational dataset only.

## Dataset and licensing

See [data/README.md](data/README.md). The Wine Recognition dataset is distributed by scikit-learn and attributed to UCI in its dataset description. Check upstream notices before reuse or redistribution.

## Security and limitations

- Educational dataset; not evidence of performance on a real business task.
- Probabilities are not guaranteed to be calibrated.
- The API has no authentication or rate limiting and should not be exposed publicly as-is.
- Only load trusted joblib artifacts.
- There is no production drift monitoring or model registry in this MVP.

## Career preparation

See [docs/career-readiness.md](docs/career-readiness.md) for role mapping, resume templates, a demo script, architecture explanation, 20 interview questions, and debugging scenarios. Only report measured results you actually obtained.

## Personal engineering contribution

Use this repository as a learning scaffold. Before publishing, be able to explain and independently modify the data split, CV procedure, metrics, API validation, and artifact workflow.
