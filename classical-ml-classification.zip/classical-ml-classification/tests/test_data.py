from classical_ml.data import load_dataset, make_split


def test_dataset_shape_and_classes():
    X, y, features, classes, _ = load_dataset()
    assert X.shape == (178, 13)
    assert len(y.unique()) == 3
    assert len(features) == 13
    assert len(classes) == 3


def test_split_is_stratified_and_repeatable():
    first, second = make_split(), make_split()
    assert first.X_train.equals(second.X_train)
    assert len(first.X_test) == 36
    assert set(first.y_train.unique()) == {0, 1, 2}


def test_invalid_test_size():
    import pytest
    with pytest.raises(ValueError):
        make_split(test_size=1.0)
