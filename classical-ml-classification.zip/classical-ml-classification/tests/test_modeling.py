from classical_ml.data import make_split
from classical_ml.modeling import train_and_evaluate


def test_training_metrics_are_valid_and_baseline_present():
    result = train_and_evaluate(make_split())
    assert 0 <= result.metrics["test_accuracy"] <= 1
    assert 0 <= result.metrics["test_f1_macro"] <= 1
    assert 0 <= result.metrics["baseline_test_accuracy"] <= 1
    assert len(result.metrics["confusion_matrix"]) == 3
    assert result.metrics["test_samples"] == 36
    assert len(result.feature_importance) == 13
    assert len(result.cv_summary) == 2
