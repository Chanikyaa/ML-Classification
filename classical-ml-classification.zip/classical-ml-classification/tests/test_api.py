from fastapi.testclient import TestClient
import joblib
from sklearn.datasets import load_wine
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from classical_ml import api


def make_test_artifact(tmp_path):
    ds = load_wine(as_frame=True)
    model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, random_state=42))
    model.fit(ds.data, ds.target)
    path = tmp_path / "model.joblib"
    joblib.dump({"model": model, "feature_names": list(ds.feature_names),
                 "target_names": list(ds.target_names), "model_version": "test-v1",
                 "dataset": "synthetic test fixture"}, path)
    api.DEFAULT_ARTIFACT = path
    api.load_artifact.cache_clear()
    return ds


def test_health_and_prediction(tmp_path):
    ds = make_test_artifact(tmp_path)
    client = TestClient(api.app)
    assert client.get("/health").status_code == 200
    payload = {"features": {name: float(value) for name, value in ds.data.iloc[0].items()}}
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["predicted_class"] in ds.target_names
    assert abs(sum(body["probabilities"].values()) - 1.0) < 1e-6


def test_rejects_missing_or_extra_features(tmp_path):
    ds = make_test_artifact(tmp_path)
    client = TestClient(api.app)
    response = client.post("/predict", json={"features": {ds.feature_names[0]: 1.0}})
    assert response.status_code == 422
    payload = {name: float(value) for name, value in ds.data.iloc[0].items()}
    payload["unknown"] = 1.0
    assert client.post("/predict", json={"features": payload}).status_code == 422


def test_model_info(tmp_path):
    ds = make_test_artifact(tmp_path)
    response = TestClient(api.app).get("/model")
    assert response.status_code == 200
    assert len(response.json()["feature_names"]) == 13


def test_home_page_and_health(tmp_path):
    make_test_artifact(tmp_path)
    client = TestClient(api.app)
    assert client.get("/").status_code == 200
    assert "Classical ML Classifier" in client.get("/").text
    assert client.get("/health").json() == {"status": "ok"}
