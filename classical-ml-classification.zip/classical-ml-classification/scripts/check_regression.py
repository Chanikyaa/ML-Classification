"""Fail if the current report misses a documented minimum-quality gate."""
import json
import sys
from pathlib import Path

report_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("reports/evaluation.json")
if not report_path.exists():
    raise SystemExit(f"Missing {report_path}; run python -m classical_ml.train first")
report = json.loads(report_path.read_text(encoding="utf-8"))
metrics = report["metrics"]
# This is an educational dataset gate, not a universal production quality threshold.
minimum_f1 = 0.80
if metrics["test_f1_macro"] < minimum_f1:
    raise SystemExit(f"Regression gate failed: test_f1_macro={metrics['test_f1_macro']:.3f} < {minimum_f1:.2f}")
print(f"Regression gate passed: test_f1_macro={metrics['test_f1_macro']:.3f} >= {minimum_f1:.2f}")
