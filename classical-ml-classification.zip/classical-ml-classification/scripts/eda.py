"""Generate a small, deterministic EDA profile without external downloads."""
import json
from pathlib import Path
from classical_ml.data import load_dataset

X, y, features, classes, _ = load_dataset()
profile = {
    "dataset": "scikit-learn Wine Recognition dataset",
    "rows": int(len(X)),
    "features": int(X.shape[1]),
    "feature_names": features,
    "class_names": classes,
    "class_counts": {classes[int(label)]: int(count) for label, count in y.value_counts().sort_index().items()},
    "missing_values_by_feature": {str(k): int(v) for k, v in X.isna().sum().items()},
    "summary_statistics": json.loads(X.describe().round(4).to_json()),
}
Path("reports").mkdir(exist_ok=True)
Path("reports/eda-profile.json").write_text(json.dumps(profile, indent=2), encoding="utf-8")
print(f"Wrote reports/eda-profile.json ({profile['rows']} rows, {profile['features']} features)")
